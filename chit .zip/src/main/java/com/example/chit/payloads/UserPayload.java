package com.example.chit.payloads;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserPayload {
	
	
	private Long userId;
	
	
	private Long chitId;

}
