package com.example.chit.Entity;

public enum Cycle {
	
	MONTHLY, QUARTERLY,YEARLY

}
