package com.example.chit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.chit.Entity.User;

@SpringBootApplication
public class ChitApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChitApplication.class, args);
		
		
		  
	}

}
