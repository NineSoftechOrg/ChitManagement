package com.example.chit.Interface;

import com.example.chit.Entity.ChitItems;
import com.example.chit.Entity.ItemUsers;

public interface ChitItemsImpl {

	ChitItems save(ChitItems chitItems);

	/* ChitItems getAllUsersInChit(ChitItems chitItems); */


}
