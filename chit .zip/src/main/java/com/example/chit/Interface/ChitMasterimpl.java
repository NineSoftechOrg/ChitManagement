package com.example.chit.Interface;

import com.example.chit.Entity.ChitMaster;

public interface ChitMasterimpl {

	ChitMaster save(ChitMaster chitMaster);

}
